package java.sql;

public record Connection() {

}
