package java.sql;

public record Timestamp() {

}
