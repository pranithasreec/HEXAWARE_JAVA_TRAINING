/**
 * 
 */
/**
 * 
 */
module Ass_Banking_System {
	requires java.sql;
	
}