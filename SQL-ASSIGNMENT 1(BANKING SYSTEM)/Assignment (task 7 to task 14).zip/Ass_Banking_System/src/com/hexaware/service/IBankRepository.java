package com.hexaware.service;

import com.hexaware.entity.Account;
import com.hexaware.entity.Transaction;
import com.hexaware.entity.Customer;
import java.util.List;

public interface IBankRepository {
    void createAccount(Customer customer, String accountType, float initialBalance);
    List<Account> listAccounts();
    float getAccountBalance(long accountNumber);
    void deposit(long accountNumber, float amount);
    void withdraw(long accountNumber, float amount);
    void transfer(long fromAccountNumber, long toAccountNumber, float amount);
    Account getAccountDetails(long accountNumber);
    List<Transaction> getTransactions(long accountNumber, java.util.Date fromDate, java.util.Date toDate);
}
