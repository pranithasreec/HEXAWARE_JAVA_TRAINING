package com.hexaware.service.impl;

import com.hexaware.entity.Account;
import com.hexaware.entity.CurrentAccount;
import com.hexaware.entity.Customer;
import com.hexaware.entity.SavingsAccount;
import com.hexaware.entity.ZeroBalanceAccount;
import com.hexaware.exception.InvalidAccountException;
import com.hexaware.exception.OverDraftLimitExceededException;
import com.hexaware.exception.InsufficientFundException;
import com.hexaware.service.IBankServiceProvider;
import java.util.ArrayList;
import java.util.List;

public class BankServiceProviderImpl extends CustomerServiceProviderImpl implements IBankServiceProvider {
    private List<Account> accountList = new ArrayList<>();

    public BankServiceProviderImpl(String branchName, String branchAddress) {
        super(); // Call the parent constructor if needed
    }

    @Override
    public Account createAccount(Customer customer, String accType, float balance) {
        CurrentAccount account = null;
        if (accType.equalsIgnoreCase("Savings")) {
            account = new SavingsAccount(balance, customer, 4.5f);
        } else if (accType.equalsIgnoreCase("Current")) {
            account = new CurrentAccount(balance, customer, 2000f);
        } else if (accType.equalsIgnoreCase("Zero Balance")) {
            account = new ZeroBalanceAccount(customer);
        }
        if (account != null) {
            accountList.add(account);
            // Add to CustomerServiceProvider to maintain consistency
            addAccount(account); // This should add the account to the parent class' accounts
        }
        return account;
    }

    @Override
    public void listAccounts() {
        for (Account account : accountList) {
            account.printAccountDetails();
        }
    }

    @Override
    public void calculateInterest() {
        for (Account account : accountList) {
            if (account instanceof SavingsAccount) {
                ((SavingsAccount) account).calculateInterest();
            }
        }
    }

    // Method to call deposit, handling the InvalidAccountException
    public void performDeposit(long accountNumber, float amount) {
        try {
            float newBalance = deposit(accountNumber, amount); // Calls deposit from CustomerServiceProviderImpl
            System.out.println("Deposit successful. New balance: " + newBalance);
        } catch (InvalidAccountException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Unexpected error: " + e.getMessage());
        }
    }

    // Method to call withdrawal, handling all relevant exceptions
    public void performWithdrawal(long accountNumber, float amount) {
        try {
            float newBalance = withdraw(accountNumber, amount); // Calls withdraw from CustomerServiceProviderImpl
            System.out.println("Withdrawal successful. New balance: " + newBalance);
        } catch (InvalidAccountException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (InsufficientFundException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (OverDraftLimitExceededException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Unexpected error: " + e.getMessage());
        }
    }

    // Method to perform fund transfer, handling all exceptions
    public void performTransfer(long fromAccountNumber, long toAccountNumber, float amount) {
        try {
            transfer(fromAccountNumber, toAccountNumber, amount); // Calls transfer from CustomerServiceProviderImpl
            System.out.println("Transfer successful.");
        } catch (InvalidAccountException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (InsufficientFundException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (OverDraftLimitExceededException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Unexpected error: " + e.getMessage());
        }
    }
}
