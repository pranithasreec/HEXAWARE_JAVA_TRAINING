package com.hexaware.service.impl;

import com.hexaware.entity.Account;
import com.hexaware.entity.CurrentAccount;
import com.hexaware.entity.SavingsAccount;
import com.hexaware.exception.InsufficientFundException;
import com.hexaware.exception.InvalidAccountException;
import com.hexaware.exception.OverDraftLimitExceededException;
import java.util.HashMap;
import java.util.Map;

public class CustomerServiceProviderImpl {

    private Map<Long, Account> accounts = new HashMap<>();

    // Method to register an account into the system
    public void addAccount(Account account) {
        accounts.put(account.getAccountNumber(), account);
    }

    // Retrieve the balance of an account
    public float getAccountBalance(long accountNumber) {
        try {
            // Fetch the account from the map using the account number
            Account account = accounts.get(accountNumber);
            
            // Check if account exists
            if (account != null) {
                return account.getBalance();
            } else {
                // If account is not found, throw InvalidAccountException
                throw new InvalidAccountException("Account not found with number: " + accountNumber);
            }
        } catch (InvalidAccountException e) {
            // Handle the exception: print the error message and return a special value (-1 or any error code)
            System.out.println("Error: " + e.getMessage());
            return -1;  // Returning -1 to indicate an error (you can choose a different approach)
        }
    }

    // Deposit an amount into an account
    public float deposit(long accountNumber, float amount) throws InvalidAccountException {
        Account account = accounts.get(accountNumber);
        if (account != null) {
            float newBalance = account.getBalance() + amount;
            account.setBalance(newBalance);
            return newBalance;
        } else {
            throw new InvalidAccountException("Account not found with number: " + accountNumber);
        }
    }

    // Withdraw an amount from an account
    public float withdraw(long accountNumber, float amount) throws InsufficientFundException, InvalidAccountException, OverDraftLimitExceededException {
        Account account = accounts.get(accountNumber);
        if (account == null) {
            throw new InvalidAccountException("Account not found with number: " + accountNumber);
        }
        if (account instanceof SavingsAccount) {
            if (account.getBalance() < amount) {
                throw new InsufficientFundException("Insufficient funds for withdrawal from account: " + accountNumber);
            } else {
                account.setBalance(account.getBalance() - amount);
                return account.getBalance();
            }
        } else if (account instanceof CurrentAccount) {
            if (account.getBalance() + ((CurrentAccount) account).getOverdraftLimit() < amount) {
                throw new OverDraftLimitExceededException("Overdraft limit exceeded in account: " + accountNumber);
            } else {
                account.setBalance(account.getBalance() - amount);
                return account.getBalance();
            }
        }
        return 0;
    }

    // Transfer funds between two accounts
    public void transfer(long fromAccountNumber, long toAccountNumber, float amount) throws InsufficientFundException, InvalidAccountException, OverDraftLimitExceededException {
        Account fromAccount = accounts.get(fromAccountNumber);
        Account toAccount = accounts.get(toAccountNumber);

        if (fromAccount == null || toAccount == null) {
            throw new InvalidAccountException("Invalid account number(s) for transfer.");
        }
        if (fromAccount.getBalance() < amount) {
            throw new InsufficientFundException("Insufficient funds in account " + fromAccountNumber);
        }
        if (fromAccount instanceof CurrentAccount && (fromAccount.getBalance() + ((CurrentAccount) fromAccount).getOverdraftLimit() < amount)) {
            throw new OverDraftLimitExceededException("Overdraft limit exceeded in account " + fromAccountNumber);
        }

        // Perform transfer
        fromAccount.setBalance(fromAccount.getBalance() - amount);
        toAccount.setBalance(toAccount.getBalance() + amount);
    }

    // Get the details of an account
    public void getAccountDetails(long accountNumber) throws InvalidAccountException {
        Account account = accounts.get(accountNumber);
        if (account == null) {
            throw new InvalidAccountException("Account not found with number: " + accountNumber);
        }
        account.printAccountDetails();
    }
}
