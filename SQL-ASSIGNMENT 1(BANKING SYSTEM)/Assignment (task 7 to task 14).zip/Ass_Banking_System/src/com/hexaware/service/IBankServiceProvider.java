package com.hexaware.service;

import com.hexaware.entity.Account;
import com.hexaware.entity.Customer;

public interface IBankServiceProvider extends ICustomerServiceProvider {
    Account createAccount(Customer customer, String accType, float balance);
    void listAccounts();
    void calculateInterest();
}
