package com.hexaware.service;

import com.hexaware.exception.InsufficientFundException;
import com.hexaware.exception.InvalidAccountException;
import com.hexaware.exception.OverDraftLimitExceededException;

public interface ICustomerServiceProvider {
    float getAccountBalance(long accountNumber);
    float deposit(long accountNumber, float amount) throws InvalidAccountException;
    float withdraw(long accountNumber, float amount) throws InsufficientFundException, InvalidAccountException, OverDraftLimitExceededException;
    void transfer(long fromAccountNumber, long toAccountNumber, float amount)throws InsufficientFundException, InvalidAccountException, OverDraftLimitExceededException;
    void getAccountDetails(long accountNumber) throws InvalidAccountException;;
}
