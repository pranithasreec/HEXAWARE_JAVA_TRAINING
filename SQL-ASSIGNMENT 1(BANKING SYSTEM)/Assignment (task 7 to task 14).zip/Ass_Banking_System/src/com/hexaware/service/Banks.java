package com.hexaware.service;

import com.hexaware.entity.Account;
import com.hexaware.entity.Customer;

import java.util.HashMap;
import java.util.Map;

public class Banks {
    private static long nextAccountNumber = 1001;
    private Map<Long, Account> accounts = new HashMap<>();

    public Account createAccount(Customer customer, String accType, float balance) {
        long accNo = nextAccountNumber++;
        Account account = new Account(accNo, accType, balance, customer);
        accounts.put(accNo, account);
        System.out.println("Account created successfully with account number: " + accNo);
        return account;
    }

    public int getAccountBalance(long accountNumber) {
        Account account = accounts.get(accountNumber);
        if (account != null) {
            return account.getAccountType();
        } else {
            System.out.println("Account not found");
            return -1;
        }
    }

    public float deposit(long accountNumber, float amount) {
        Account account = accounts.get(accountNumber);
        if (account != null) {
            float newBalance = account.getAccountType() + amount;
            account.setAccountBalance(newBalance);
            return newBalance;
        } else {
            System.out.println("Account not found");
            return 0;
        }
    }

    public float withdraw(long accountNumber, float amount) {
        Account account = accounts.get(accountNumber);
        if (account != null) {
            float currentBalance = account.getAccountType();
            if (amount <= currentBalance) {
                float newBalance = currentBalance - amount;
                account.setAccountBalance(newBalance);
                return newBalance;
            } else {
                System.out.println("Insufficient balance");
            }
        } else {
            System.out.println("Account not found");
        }
        return 0;
    }

    public void transfer(long fromAcc, long toAcc, float amount) {
        Account fromAccount = accounts.get(fromAcc);
        Account toAccount = accounts.get(toAcc);

        if (fromAccount == null || toAccount == null) {
            System.out.println("One or both account numbers are invalid");
            return;
        }

        if (fromAccount.getAccountType() >= amount) {
            fromAccount.setAccountBalance(fromAccount.getAccountType() - amount);
            toAccount.setAccountBalance(toAccount.getAccountType() + amount);
            System.out.println("Transfer successful");
        } else {
            System.out.println("Insufficient funds in source account");
        }
    }

    public void getAccountDetails(long accountNumber) {
        Account account = accounts.get(accountNumber);
        if (account != null) {
            account.printAccountDetails();
        } else {
            System.out.println("Account not found");
        }
    }
}
