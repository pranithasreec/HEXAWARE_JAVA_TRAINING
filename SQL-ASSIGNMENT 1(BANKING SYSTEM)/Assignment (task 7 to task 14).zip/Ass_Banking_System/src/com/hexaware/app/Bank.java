package com.hexaware.app;

import com.hexaware.entity.*;
import com.hexaware.service.impl.*;
import com.hexaware.exception.*;
import java.util.Scanner;

public class Bank {
    public static void main(String[] args) throws InvalidAccountException {
        Scanner sc = new Scanner(System.in);
        BankServiceProviderImpl bankService = new BankServiceProviderImpl("Hexaware Branch", "123 Main St");

        while (true) {
            try {
                System.out.println("Enter a choice:");
                System.out.println("1. Create Account");
                System.out.println("2. Deposit");
                System.out.println("3. Withdraw");
                System.out.println("4. Get Balance");
                System.out.println("5. Transfer");
                System.out.println("6. Get Account Details");
                System.out.println("7. List Accounts");
                System.out.println("8. Exit");

                int choice = sc.nextInt();

                switch (choice) {
                    case 1:
                        System.out.println("Enter Customer ID: ");
                        int customerId = sc.nextInt();
                        sc.nextLine(); // Consume newline
                        System.out.println("Enter Customer Name: ");
                        String name = sc.nextLine();
                        System.out.println("Enter Account Type (Savings/Current/Zero Balance): ");
                        String accType = sc.nextLine();
                        System.out.println("Enter initial balance: ");
                        float balance = sc.nextFloat();

                        Customer customer = new Customer(customerId, name, "", "", "", "");
                        bankService.createAccount(customer, accType, balance);
                        break;

                    case 2:
                        System.out.println("Enter account number to deposit to: ");
                        long accNoDeposit = sc.nextLong();
                        System.out.println("Enter amount to deposit: ");
                        float depositAmount = sc.nextFloat();
                        try {
                            bankService.deposit(accNoDeposit, depositAmount);
                        } catch (InvalidAccountException e) {
                            System.out.println("Error: " + e.getMessage());
                        }
                        break;

                    case 3:
                        System.out.println("Enter account number to withdraw from: ");
                        long accNoWithdraw = sc.nextLong();
                        System.out.println("Enter amount to withdraw: ");
                        float withdrawAmount = sc.nextFloat();
                        try {
                            bankService.withdraw(accNoWithdraw, withdrawAmount);
                        } catch (InsufficientFundException | InvalidAccountException | OverDraftLimitExceededException e) {
                            System.out.println("Error: " + e.getMessage());
                        }
                        break;

                    case 4:
                        System.out.println("Enter account number to get balance: ");
                        long accNoBalance = sc.nextLong();
					System.out.println("Balance: " + bankService.getAccountBalance(accNoBalance));
                        break;

                    case 5:
                        System.out.println("Enter from account number: ");
                        long fromAccNo = sc.nextLong();
                        System.out.println("Enter to account number: ");
                        long toAccNo = sc.nextLong();
                        System.out.println("Enter amount to transfer: ");
                        float transferAmount = sc.nextFloat();
                        try {
                            bankService.transfer(fromAccNo, toAccNo, transferAmount);
                        } catch (InsufficientFundException | InvalidAccountException | OverDraftLimitExceededException e) {
                            System.out.println("Error: " + e.getMessage());
                        }
                        break;

                    case 6:
                        System.out.println("Enter account number to get details: ");
                        long accNoDetails = sc.nextLong();
                        try {
                            bankService.getAccountDetails(accNoDetails);
                        } catch (InvalidAccountException e) {
                            System.out.println("Error: " + e.getMessage());
                        }
                        break;

                    case 7:
                        bankService.listAccounts();
                        break;

                    case 8:
                        System.out.println("Exiting...");
                        sc.close();
                        return;

                    default:
                        System.out.println("Invalid choice. Please try again.");
                        break;
                }
            } catch (NullPointerException e) {
                System.out.println("NullPointerException caught: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("An unexpected error occurred: " + e.getMessage());
            }
        }
    }
}
