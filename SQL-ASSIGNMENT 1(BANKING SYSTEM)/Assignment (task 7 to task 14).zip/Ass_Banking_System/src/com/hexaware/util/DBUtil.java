package com.hexaware.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {
    private static final String URL = "jdbc:mysql://localhost:3306/bankdb";
    private static final String USER = "root";
    private static final String PASSWORD = "password";

    public static Connection getDBConn() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
