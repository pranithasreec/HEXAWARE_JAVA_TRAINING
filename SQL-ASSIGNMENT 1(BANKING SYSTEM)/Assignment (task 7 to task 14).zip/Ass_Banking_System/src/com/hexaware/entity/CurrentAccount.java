package com.hexaware.entity;

public class CurrentAccount extends BankAccount {
    private static final double OVERDRAFT_LIMIT = 10000.0;

    public CurrentAccount() {}

    public CurrentAccount(int accountNumber, String customerName, double balance) {
        super(accountNumber, customerName, balance);
    }

    @Override
    public void deposit(float amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println(amount + " deposited successfully");
        } else {
            System.out.println("Invalid deposit amount");
        }
    }

    @Override
    public void withdraw(float amount) {
        if (amount > 0 && amount <= (balance + OVERDRAFT_LIMIT)) {
            balance -= amount;
            System.out.println(amount + " withdrawn successfully");
        } else {
            System.out.println("Overdraft limit exceeded or invalid amount");
        }
    }

    @Override
    public void calculateInterest() {
        System.out.println("Current accounts do not earn interest");
    }
}
