package com.hexaware.entity;

public class ZeroBalanceAccount extends Account {
    public ZeroBalanceAccount(Customer customer) {
        super("Zero Balance", 0, customer);
    }

    @Override
    public void withdraw(float amount) {
        System.out.println("Cannot withdraw from a Zero Balance Account.");
    }
}
