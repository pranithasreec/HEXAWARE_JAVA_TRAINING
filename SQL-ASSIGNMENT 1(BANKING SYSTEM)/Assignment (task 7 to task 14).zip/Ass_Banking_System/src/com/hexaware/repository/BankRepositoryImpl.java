package com.hexaware.repository;

import com.hexaware.entity.*;
import com.hexaware.service.IBankRepository;
import com.hexaware.util.DBUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BankRepositoryImpl implements IBankRepository {
    @Override
    public void createAccount(Customer customer, String accountType, float initialBalance) {
        try (Connection conn = DBUtil.getDBConn()) {
            String query = "INSERT INTO accounts (customer_id, account_type, balance) VALUES (?, ?, ?)";
            try (PreparedStatement ps = conn.prepareStatement(query)) {
                ps.setLong(1, customer.getCustomerId());
                ps.setString(2, accountType);
                ps.setFloat(3, initialBalance);
                ps.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Account> listAccounts() {
        List<Account> accounts = new ArrayList<>();
        try (Connection conn = DBUtil.getDBConn()) {
            String query = "SELECT * FROM accounts";
            try (Statement stmt = conn.createStatement()) {
                ResultSet rs = stmt.executeQuery(query);
                while (rs.next()) {
                    long accountId = rs.getLong("account_number");
                    // Add logic to fetch account data and create appropriate Account object
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return accounts;
    }

    // Implement other methods like deposit, withdraw, transfer, etc.
}
